from flask import Flask, render_template, request, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from flask_sqlalchemy import SQLAlchemy
#logging in
from flask_login import LoginManager, UserMixin, login_required, login_user, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from forms import userregister, newjob
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'itsasecret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///myDB.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

#initialize login manager tools
login_manager = LoginManager()
login_manager.init_app(app)

#initialize the uploads temp folder for job files for bytes conversion
os.makedirs('uploads', exist_ok=True)
app.config['UPLOAD_FOLDER'] = 'uploads'

#have to have db exist to run this so run a seed.py file first
from models import User, JobTemplate, MeasurementRun, Artifacts, PointSamples

with app.app_context():
    db.create_all()

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

@app.route('/', methods=['GET', 'POST'])
def login():
    #the base route is going to be a login page instead of a home page.
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        #if the username is found and the password was entered right
        if user and check_password_hash(user.password_hash, password):
            #lig them in and redirect to the jobs page
            login_user(user)
            return redirect(url_for('jobs'))
        else:
            return render_template('login.html', error='Invalid Login Information')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    userregisterform = userregister()
    if userregisterform.validate_on_submit():
        username = userregisterform.username.data
        if userregisterform.password.data == userregisterform.password2.data:
            password = generate_password_hash(userregisterform.password.data)
        else:
            return render_template('register.html', template_form = userregisterform, error='passwords do not match')
        if User.query.filter_by(username=username).first():
            return render_template('register.html', template_form = userregisterform, error='user already exists')
        user = User(username=username,password_hash=password)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html', template_form = userregisterform)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/jobs', methods=['GET', 'POST'])
@login_required
def jobs():
    #want to be able to add a job to run
        #in top toolbar of html need a add a job button that opens a different route
    #want to be able to open a job
        #have a list of all job names available to be run
        #have buttons by each name to launch the job
    return render_template('jobs.html')

@app.route('/addjob', methods = ['GET', 'POST'])
@login_required
def addjob():
    newjobform = newjob()
    if newjobform.validate_on_submit():
        upload=newjobform.file.data
        if upload is None or upload.filename == "":
            return 'no file was selected'
        raw=upload.read() #bytes for sql upload
        created_by_id = current_user.id
        name = newjobform.jobname.data
        description = newjobform.description.data
        nominalpointcount = newjobform.nominalpointcount.data
        newjobinfo = JobTemplate(
            Name=name, description=description, 
            nominal_point_count=nominalpointcount,
            created_by_id=created_by_id,
            template_file=raw)
        db.session.add(newjobinfo)
        db.session.commit()
        return redirect(url_for('jobs'))
    return render_template('add_job.html', template_form = newjobform)

@app.route('/about', methods=['GET', 'POST'])
def about():
    return render_template('about.html')
