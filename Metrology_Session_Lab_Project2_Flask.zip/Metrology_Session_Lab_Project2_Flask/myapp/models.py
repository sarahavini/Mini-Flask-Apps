#only model classes go in this file. this file doesnt make the db or add to it
from app import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    id=db.Column(db.Integer, primary_key=True)
    username=db.Column(db.String, index = True, unique = True)
    password_hash=db.Column(db.String)
    #a .creator attribute is added to JobTemplate
    jobtemplates=db.relationship(
        'JobTemplate',
        #foreign_keys=['JobTemplate.created_by_id'],
        #primaryjoin='User.id==JobTemplate.created_by_id',
        backref='creator',
        lazy = True,
        cascade = "all, delete-orphan"
    )
    #adds a .creator attribute to measurementrun
    measurementruns=db.relationship(
        'MeasurementRun',
        #foreign_keys=['MeasurementRun.measured_by_user_id'],
        #primaryjoin='User.id==MeasurementRun.measured_by_user_id',
        backref='creator',
        lazy = True,
        cascade = "all, delete-orphan"     
    )

class JobTemplate(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    Name=db.Column(db.String, index = True, unique = True)
    description=db.Column(db.String, index = True)
    template_file= db.Column(db.LargeBinary, nullable=False) #the .xit in bianary
    nominal_point_count=db.Column(db.Integer)
    #link the created by id to the users table
    created_by_id=db.Column(db.Integer, db.ForeignKey(User.id), nullable=False)
    #add a .templateid attribute to MeasurementRun
    measurementruns=db.relationship(
        'MeasurementRun',
        #foreign_keys=['MeasurementRun.template_file_id'],
        #primaryjoin='JobTemplate.id==MeasurementRun.template_file_id',
        backref='templateid',
        lazy = True,
        cascade = "all, delete-orphan"     
    )

class MeasurementRun(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    measured_by_user_id=db.Column(db.Integer, db.ForeignKey(User.id), nullable=False)
    template_file_id=db.Column(db.Integer, db.ForeignKey(JobTemplate.id), nullable=False)
    started_at=db.Column(db.DateTime, nullable=True)
    finished_at=db.Column(db.DateTime, nullable=True)
    number_nominal_points=db.Column(db.Integer, nullable=True)
    number_measured_points=db.Column(db.Integer, nullable=True)
    rms_of_fit=db.Column(db.Float, nullable = True)
    job_status=db.Column(db.String, nullable=True)
    error_text=db.Column(db.String, nullable=True)
    #add a .MeasurementId attribute to artifacts
    artifacts=db.relationship(
        'Artifacts',
        #foreign_keys=['Artifacts.measurement_run_id'],
        #primaryjoin='MeasurementRun.id==Artifacts.measurement_run_id',
        backref='MeasurementId',
        lazy = True,
        cascade = "all, delete-orphan"     
    )
    #add a .MeasurementId attribute to pointsamples
    pointsamples=db.relationship(
        'PointSamples',
        #foreign_keys=['PointSamples.measurement_run_id'],
        #primaryjoin='MeasurementRun.id==PointSamples.measurement_run_id',
        backref='MeasurementId',
        lazy = True,
        cascade = "all, delete-orphan"     
    )

class Artifacts(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    measurement_run_id=db.Column(db.Integer, db.ForeignKey(MeasurementRun.id), nullable=False)
    artifact_kind=db.Column(db.String, nullable=False) #measured_job_file, vector_image
    filename=db.Column(db.String, nullable=False) #safilename.xit or vectorgroup1.jpg
    mime_type=db.Column(db.String, nullable=False) #tells the browser what to expect, jpg, png, etc
    data=db.Column(db.LargeBinary, nullable=False)
    byte_size=db.Column(db.Integer, nullable=False)

class PointSamples(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    measurement_run_id=db.Column(db.Integer, db.ForeignKey(MeasurementRun.id), nullable=False)
    name=db.Column(db.String, nullable = True) #The point name from SA
    nom_x=db.Column(db.Float, nullable = True)
    nom_y =db.Column(db.Float, nullable = True)
    nomimal_z=db.Column(db.Float, nullable = True)
    measured_x=db.Column(db.Float, nullable = True)
    measured_y=db.Column(db.Float, nullable = True)
    measured_z=db.Column(db.Float, nullable = True)
    residual=db.Column(db.Float, nullable = True)