#this file makes the objects to put on the html forms. The html only renders what you create here

from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, BooleanField, SelectField, PasswordField, IntegerField, FileField
from wtforms.validators import DataRequired, Length
from flask_wtf.file import FileField, FileRequired


class userregister(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = StringField('Password', validators=[DataRequired()])
    password2 = StringField('Repeat password', validators=[DataRequired()])
    submit = SubmitField('Register')

class newjob(FlaskForm):
    jobname = StringField('Job Name', validators=[DataRequired()])
    description = StringField('Job Description', validators=[DataRequired()])
    nominalpointcount = IntegerField('Nominal Point Count', validators=[DataRequired()])
    file = FileField("Job Template", validators=[FileRequired()])
    submit = SubmitField('Register')
