from datetime import datetime, timezone

from werkzeug.security import generate_password_hash

from app import app, db
from models import User, JobTemplate, MeasurementRun, Artifacts, PointSamples


def utcnow():
    return datetime.now(timezone.utc)


def seed():
    with app.app_context():
        db.create_all()

        user = db.session.query(User).filter_by(username="admin").first()
        if user is None:
            user = User(
                username="admin",
                password_hash=generate_password_hash("changeme"),
            )
            db.session.add(user)
            db.session.flush()
            print(f"Created user id={user.id}")
        else:
            print(f"User exists id={user.id}")

        template = db.session.query(JobTemplate).filter_by(Name="Demo Template").first()
        if template is None:
            template = JobTemplate(
                Name="Demo Template",
                description="Starter job template created by seed.py",
                template_file=b"XIT-PLACEHOLDER\n",
                nominal_point_count=3,
                created_by_id=user.id,
            )
            db.session.add(template)
            db.session.flush()
            print(f"Created JobTemplate id={template.id}")
        else:
            print(f"JobTemplate exists id={template.id}")

        run = (
            db.session.query(MeasurementRun)
            .filter_by(measured_by_user_id=user.id, template_file_id=template.id)
            .first()
        )
        if run is None:
            now = utcnow()
            run = MeasurementRun(
                measured_by_user_id=user.id,
                template_file_id=template.id,
                started_at=now,
                finished_at=now,
                number_nominal_points=3,
                number_measured_points=3,
                rms_of_fit=0.0123,
                job_status="complete",
                error_text=None,
            )
            db.session.add(run)
            db.session.flush()
            print(f"Created MeasurementRun id={run.id}")
        else:
            print(f"MeasurementRun exists id={run.id}")

        if db.session.query(Artifacts).filter_by(measurement_run_id=run.id).count() == 0:
            jpg = b"\xff\xd8\xff\xd9"
            xit = b"XIT-MEASURED-PLACEHOLDER\n"
            db.session.add(
                Artifacts(
                    measurement_run_id=run.id,
                    artifact_kind="vector_image",
                    filename="demo_vector.jpg",
                    mime_type="image/jpeg",
                    data=jpg,
                    byte_size=len(jpg),
                )
            )
            db.session.add(
                Artifacts(
                    measurement_run_id=run.id,
                    artifact_kind="measured_job_file",
                    filename="demo_measured.xit",
                    mime_type="application/octet-stream",
                    data=xit,
                    byte_size=len(xit),
                )
            )
            print("Created Artifacts")

        if db.session.query(PointSamples).filter_by(measurement_run_id=run.id).count() == 0:
            for name, nx, ny, nz, mx, my, mz, residual in [
                ("P1", 0.0, 0.0, 0.0, 0.001, -0.002, 0.0005, 0.0023),
                ("P2", 10.0, 0.0, 0.0, 10.002, 0.001, -0.001, 0.0024),
                ("P3", 10.0, 10.0, 0.0, 9.998, 10.001, 0.002, 0.0030),
            ]:
                db.session.add(
                    PointSamples(
                        measurement_run_id=run.id,
                        name=name,
                        nom_x=nx,
                        nom_y=ny,
                        nomimal_z=nz,
                        measured_x=mx,
                        measured_y=my,
                        measured_z=mz,
                        residual=residual,
                    )
                )
            print("Created PointSamples")

        db.session.commit()
        print("Seed complete.")


if __name__ == "__main__":
    seed()