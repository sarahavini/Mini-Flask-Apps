from app import app, db, JobTemplate
with app.app_context():
    j = JobTemplate.query.order_by(JobTemplate.id.desc()).first()
    print(j.id, j.Name, type(j.template_file), len(j.template_file or b""))