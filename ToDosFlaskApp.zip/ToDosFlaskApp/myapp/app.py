from flask import Flask, render_template, request
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mysecret'

#####DATA BASE CONFIGURATIONS
#the location of where the database is stored, can be local server or on internet
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///myDB.db' 
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
#this connects the sql alchemy library to the app
db = SQLAlchemy(app)
#######END DATABASE CONFIGURATIONS

#instead of using a list of strings for the todos ...
todos = [" Learn Flask", "Setup Venv", "Build Cool App"]

#use a data base model
class Todo(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    todo_text = db.Column(db.String(100), index=True)


class TodoForm(FlaskForm):
    todo = StringField("Todo")
    submit = SubmitField("Add Todo")

#create the database starting in sqlalchamy v3 you need the app context line
#once a database is created you do not need to run this line again.
with app.app_context():
    db.create_all()

@app.route('/',methods=["GET", "POST"])
def index():
    #if a POST request is made from the form with the attribute of todo
    if "todo" in request.form:
        db.session.add(Todo(todo_text = request.form['todo']))
        db.session.commit()
    return render_template("index.html", todoslist = Todo.query.all(), template_form=TodoForm())