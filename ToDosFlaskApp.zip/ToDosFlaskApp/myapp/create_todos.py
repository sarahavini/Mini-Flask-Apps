from app import app, db, Todo

with app.app_context():
    #add this item to the database eveytime this file is run
    first_todo = Todo(todo_text="Learn Flask")
    db.session.add(first_todo)

    #or do it in one line
    db.session.add(Todo(todo_text="Build a cool app"))

    #commit the changes to the data base 
    db.session.commit()

    #query the todos and print the text of the first one
    all_todo = Todo.query.all()
    print(all_todo[0].todo_text)